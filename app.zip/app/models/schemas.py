from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


# ── Chat ──────────────────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    session_id: str
    message: str
    nickname: Optional[str] = None


class MoodData(BaseModel):
    mood: str
    intensity: int = Field(ge=1, le=10)
    sentiment: str
    triggers: List[str] = []
    crisis_detected: bool = False
    suggested_intervention: Optional[str] = None


class ChatResponse(BaseModel):
    session_id: str
    reply: str
    mood_data: Optional[MoodData] = None
    crisis_resources: Optional[dict] = None
    suggested_wellness: Optional[List[dict]] = None


# ── Mood ──────────────────────────────────────────────────────────────────────

class MoodLogRequest(BaseModel):
    session_id: str
    mood: str
    intensity: int = Field(ge=1, le=10)
    triggers: Optional[List[str]] = []
    notes: Optional[str] = None
    source: str = "manual"


class MoodEntryResponse(BaseModel):
    id: int
    session_id: str
    mood: str
    intensity: int
    triggers: Optional[List[str]]
    notes: Optional[str]
    source: str
    created_at: datetime

    class Config:
        from_attributes = True


class MoodInsights(BaseModel):
    average_intensity: float
    dominant_mood: str
    mood_distribution: dict
    common_triggers: List[str]
    trend: str          # 'improving' | 'declining' | 'stable'
    streak_days: int


# ── Wellness ──────────────────────────────────────────────────────────────────

class WellnessTip(BaseModel):
    id: str
    title: str
    category: str
    tagline: str
    duration: str
    difficulty: str
    mood_tags: List[str]
    description: str
    benefits: List[str]


class Intervention(BaseModel):
    id: str
    name: str
    category: str
    steps: List[dict]
    duration_minutes: int
    science: str


# ── Analytics ─────────────────────────────────────────────────────────────────

class PatternInsight(BaseModel):
    type: str
    description: str
    severity: str       # 'info' | 'warning' | 'alert'
    recommendation: str


class AnalyticsSummary(BaseModel):
    total_sessions: int
    total_messages: int
    mood_insights: MoodInsights
    patterns: List[PatternInsight]
    personalized_recommendations: List[str]
