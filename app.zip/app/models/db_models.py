from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Float
from sqlalchemy.sql import func
from app.database import Base


class Session(Base):
    __tablename__ = "sessions"

    id = Column(String, primary_key=True, index=True)
    nickname = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    last_active = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    total_messages = Column(Integer, default=0)
    crisis_count = Column(Integer, default=0)


class Message(Base):
    __tablename__ = "messages"

    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String, index=True, nullable=False)
    role = Column(String, nullable=False)          # 'user' | 'assistant'
    content = Column(Text, nullable=False)
    mood = Column(String, nullable=True)           # detected mood
    mood_intensity = Column(Integer, nullable=True)  # 1-10
    sentiment = Column(String, nullable=True)      # positive | negative | neutral
    triggers = Column(Text, nullable=True)         # JSON array string
    crisis_detected = Column(Boolean, default=False)
    intervention_suggested = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class MoodEntry(Base):
    __tablename__ = "mood_entries"

    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String, index=True, nullable=False)
    mood = Column(String, nullable=False)
    intensity = Column(Integer, nullable=False)    # 1-10
    triggers = Column(Text, nullable=True)         # JSON array string
    notes = Column(Text, nullable=True)
    source = Column(String, default="chat")        # 'chat' | 'manual'
    created_at = Column(DateTime(timezone=True), server_default=func.now())
