"""
Wellness Service — Manages the wellness tips and micro-interventions library.
"""

import json
import random
from pathlib import Path
from functools import lru_cache
from typing import Optional

DATA_DIR = Path(__file__).parent.parent / "data"

MOOD_TO_CATEGORIES = {
    "anxious":     ["breathing", "grounding", "mindfulness", "movement"],
    "stressed":    ["breathing", "movement", "cognitive", "mindfulness"],
    "sad":         ["mindfulness", "journaling", "cognitive", "movement"],
    "angry":       ["breathing", "movement", "grounding", "cognitive"],
    "overwhelmed": ["breathing", "grounding", "cognitive", "movement"],
    "hopeless":    ["mindfulness", "journaling", "cognitive", "movement"],
    "confused":    ["grounding", "journaling", "cognitive"],
    "happy":       ["journaling", "mindfulness", "movement"],
    "calm":        ["mindfulness", "journaling"],
    "hopeful":     ["journaling", "mindfulness"],
    "neutral":     ["breathing", "mindfulness", "journaling"],
}


@lru_cache(maxsize=1)
def _load_tips() -> dict:
    with open(DATA_DIR / "wellness_tips.json", "r", encoding="utf-8") as f:
        return json.load(f)


@lru_cache(maxsize=1)
def _load_interventions() -> dict:
    with open(DATA_DIR / "interventions.json", "r", encoding="utf-8") as f:
        return json.load(f)


def get_all_categories() -> list[dict]:
    """Return all wellness categories with metadata."""
    data = _load_tips()
    return [
        {
            "id": cat["id"],
            "name": cat["name"],
            "icon": cat["icon"],
            "color": cat["color"],
            "description": cat["description"],
            "tip_count": len(cat["tips"]),
        }
        for cat in data["categories"]
    ]


def get_tips_by_mood(mood: str, limit: int = 3) -> list[dict]:
    """Return wellness tips most relevant to the given mood."""
    data = _load_tips()
    priority_categories = MOOD_TO_CATEGORIES.get(mood.lower(), ["breathing", "mindfulness"])
    results = []

    # First pass: exact mood tag match in priority categories
    for cat in data["categories"]:
        if cat["id"] in priority_categories:
            for tip in cat["tips"]:
                if mood.lower() in tip.get("mood_tags", []):
                    results.append({**tip, "category": cat["id"], "category_name": cat["name"]})

    # Second pass: any tip from priority categories
    if len(results) < limit:
        for cat in data["categories"]:
            if cat["id"] in priority_categories:
                for tip in cat["tips"]:
                    entry = {**tip, "category": cat["id"], "category_name": cat["name"]}
                    if entry not in results:
                        results.append(entry)

    return results[:limit]


def get_all_tips() -> list[dict]:
    """Return all tips across all categories."""
    data = _load_tips()
    all_tips = []
    for cat in data["categories"]:
        for tip in cat["tips"]:
            all_tips.append({
                **tip,
                "category": cat["id"],
                "category_name": cat["name"],
                "category_color": cat["color"],
            })
    return all_tips


def get_tips_by_category(category_id: str) -> list[dict]:
    """Return all tips for a specific category."""
    data = _load_tips()
    for cat in data["categories"]:
        if cat["id"] == category_id:
            return [
                {**tip, "category": cat["id"], "category_name": cat["name"]}
                for tip in cat["tips"]
            ]
    return []


def get_intervention(intervention_id: str) -> Optional[dict]:
    """Return a specific micro-intervention by ID."""
    data = _load_interventions()
    return data["interventions"].get(intervention_id)


def get_intervention_for_mood(mood: str) -> Optional[dict]:
    """Get the most appropriate intervention for a mood."""
    mood_to_intervention = {
        "anxious":     "box_breathing",
        "stressed":    "physiological_sigh",
        "overwhelmed": "grounding_54321",
        "angry":       "pmr",
        "sad":         "self_compassion",
        "hopeless":    "gratitude_practice",
        "confused":    "journaling",
        "happy":       "gratitude_practice",
        "calm":        "loving_kindness",
        "hopeful":     "journaling",
    }
    intervention_id = mood_to_intervention.get(mood.lower(), "box_breathing")
    return get_intervention(intervention_id)


def get_daily_tip() -> dict:
    """Return a random wellness tip for the day."""
    all_tips = get_all_tips()
    return random.choice(all_tips) if all_tips else {}
