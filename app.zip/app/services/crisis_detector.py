"""
Crisis Detector — Safety-critical module.

Uses layered detection: keyword matching + contextual scoring.
Any positive detection immediately triggers crisis resources.
"""

import re
from dataclasses import dataclass, field
from typing import Optional

# ── Crisis Keywords ────────────────────────────────────────────────────────────

# Tier 1: Explicit/immediate — always flag
TIER1_PATTERNS = [
    r"\bkill\s*(my)?self\b",
    r"\bend\s+my\s+life\b",
    r"\bsuicid\w*\b",
    r"\bwant\s+to\s+die\b",
    r"\bdon['']?t\s+want\s+to\s+(be\s+)?alive\b",
    r"\btake\s+my\s+(own\s+)?life\b",
    r"\bno\s+reason\s+to\s+live\b",
    r"\bbetter\s+off\s+(without\s+me|dead)\b",
    r"\bself[\s-]?harm\b",
    r"\bcut\s+(my)?self\b",
    r"\bhurt\s+(my)?self\b",
    r"\boverdos\w*\b",
]

# Tier 2: High-risk expressions — flag with context
TIER2_PATTERNS = [
    r"\bcan'?t\s+(go on|take it|do this)\b",
    r"\bgive\s+up\s+on\s+(everything|life|myself)\b",
    r"\bnothing\s+to\s+live\s+for\b",
    r"\bfeel\s+like\s+disappearing\b",
    r"\bnobody\s+(cares|would\s+miss\s+me)\b",
    r"\bwish\s+I\s+(was|were)\s+(never\s+born|dead)\b",
    r"\bsay\s+goodbye\b",
    r"\bfinal\s+(note|letter|goodbye)\b",
    r"\bpainful\s+to\s+exist\b",
    r"\bcan'?t\s+see\s+a\s+way\s+out\b",
    r"\btrapped\s+and\s+hopeless\b",
]

# Tier 3: Concerning but may be idiomatic — note but don't always flag
TIER3_PATTERNS = [
    r"\bI'?m\s+done\b",
    r"\bso\s+done\s+with\s+(this|life|everything)\b",
    r"\bcompletely\s+hopeless\b",
    r"\bno\s+way\s+out\b",
    r"\bcan'?t\s+(do\s+this\s+anymore|keep\s+going)\b",
]


# ── Crisis Resources ──────────────────────────────────────────────────────────

CRISIS_RESOURCES = {
    "primary": {
        "name": "988 Suicide & Crisis Lifeline",
        "contact": "Call or text 988",
        "description": "Free, confidential support 24/7",
        "url": "https://988lifeline.org",
    },
    "text": {
        "name": "Crisis Text Line",
        "contact": "Text HOME to 741741",
        "description": "Free crisis counseling via text, 24/7",
        "url": "https://www.crisistextline.org",
    },
    "international": {
        "name": "International Association for Suicide Prevention",
        "contact": "https://www.iasp.info/resources/Crisis_Centres/",
        "description": "Crisis centers worldwide",
        "url": "https://www.iasp.info/resources/Crisis_Centres/",
    },
    "chat": {
        "name": "Crisis Chat",
        "contact": "https://988lifeline.org/chat/",
        "description": "Live chat with crisis counselor",
        "url": "https://988lifeline.org/chat/",
    },
}


# ── Detection Result ──────────────────────────────────────────────────────────

@dataclass
class CrisisResult:
    is_crisis: bool
    tier: int = 0                    # 0=none, 1=explicit, 2=high-risk, 3=concerning
    matched_patterns: list = field(default_factory=list)
    resources: Optional[dict] = None
    safe_message_prefix: str = ""


# ── Detector ──────────────────────────────────────────────────────────────────

def detect_crisis(message: str) -> CrisisResult:
    """
    Multi-tier crisis detection using regex pattern matching.

    Returns CrisisResult with severity tier and appropriate resources.
    This is a first-line filter; the AI service also detects subtle crisis signals.
    """
    normalized = message.lower().strip()
    matched = []

    # Tier 1 check — explicit statements
    for pattern in TIER1_PATTERNS:
        if re.search(pattern, normalized, re.IGNORECASE):
            matched.append(pattern)

    if matched:
        return CrisisResult(
            is_crisis=True,
            tier=1,
            matched_patterns=matched,
            resources=CRISIS_RESOURCES,
            safe_message_prefix=_get_crisis_prefix(tier=1),
        )

    # Tier 2 check — high-risk expressions
    matched = []
    for pattern in TIER2_PATTERNS:
        if re.search(pattern, normalized, re.IGNORECASE):
            matched.append(pattern)

    if matched:
        return CrisisResult(
            is_crisis=True,
            tier=2,
            matched_patterns=matched,
            resources=CRISIS_RESOURCES,
            safe_message_prefix=_get_crisis_prefix(tier=2),
        )

    # Tier 3 check — concerning but context-dependent
    matched = []
    for pattern in TIER3_PATTERNS:
        if re.search(pattern, normalized, re.IGNORECASE):
            matched.append(pattern)

    if len(matched) >= 2:
        # Multiple tier-3 hits = treat as tier-2
        return CrisisResult(
            is_crisis=True,
            tier=2,
            matched_patterns=matched,
            resources=CRISIS_RESOURCES,
            safe_message_prefix=_get_crisis_prefix(tier=2),
        )

    return CrisisResult(is_crisis=False, tier=0)


def _get_crisis_prefix(tier: int) -> str:
    if tier == 1:
        return (
            "I'm so glad you reached out, and I want you to know I hear you — "
            "what you're feeling right now matters deeply. You are not alone in this. "
            "Please know that immediate support is available right now:\n\n"
            "📞 **988 Suicide & Crisis Lifeline** — Call or text **988** (free, 24/7)\n"
            "💬 **Crisis Text Line** — Text **HOME** to **741741**\n\n"
        )
    return (
        "I can hear that you're going through something really painful right now, "
        "and I want you to know you don't have to face this alone. "
        "If things feel too heavy, please reach out:\n\n"
        "📞 **988 Suicide & Crisis Lifeline** — Call or text **988** (free, 24/7)\n"
        "💬 **Crisis Text Line** — Text **HOME** to **741741**\n\n"
    )


def should_prepend_resources(ai_response: str, crisis_result: CrisisResult) -> str:
    """Prepend crisis resources to AI response when crisis is detected."""
    if not crisis_result.is_crisis:
        return ai_response
    return crisis_result.safe_message_prefix + ai_response
