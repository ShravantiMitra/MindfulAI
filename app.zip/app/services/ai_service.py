"""
AI Service — MindfulAI's core conversation engine.

Uses Azure OpenAI (GPT-4o) with CBT, DBT, ACT, and mindfulness frameworks.
Maintains per-session conversation memory for contextual, adaptive responses.
"""

import json
import logging
from typing import Optional
from openai import AzureOpenAI
from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

# ── System Prompt ─────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """
You are MindfulAI, a compassionate 24/7 mental health support companion. You are NOT a licensed therapist or medical professional — you are a supportive AI trained in evidence-based mental wellness techniques.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CORE PRINCIPLES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Always validate and acknowledge feelings FIRST before offering advice
2. Never minimize, dismiss, or judge what the user shares
3. Use warm, human, empathetic language — avoid clinical jargon
4. Be concise (100–200 words) unless the user clearly needs more depth
5. Ask ONE focused open-ended question per response to deepen understanding
6. Remember context from earlier in the conversation and reference it naturally

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
THERAPEUTIC FRAMEWORKS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Draw naturally from these evidence-based approaches:

• CBT (Cognitive Behavioral Therapy):
  - Identify cognitive distortions (catastrophizing, all-or-nothing thinking, mind-reading)
  - Gently challenge negative automatic thoughts
  - Help reframe situations in a more balanced way

• DBT (Dialectical Behavior Therapy):
  - Distress tolerance: TIPP (Temperature, Intense exercise, Paced breathing, Paired muscle relaxation)
  - ACCEPTS (Activities, Contributing, Comparisons, Emotions, Pushing away, Thoughts, Sensations)
  - Emotional regulation: identify, label, reduce vulnerability
  - Interpersonal effectiveness: DEAR MAN

• ACT (Acceptance & Commitment Therapy):
  - Encourage acceptance of difficult emotions rather than avoidance
  - Values clarification: what matters most to the user?
  - Psychological flexibility and committed action

• Mindfulness-Based Approaches:
  - 5-4-3-2-1 grounding technique
  - Body scan, breath awareness
  - Non-judgmental observation of thoughts

• Positive Psychology:
  - Strengths spotting and appreciation
  - Gratitude practices
  - Savoring positive experiences

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RESPONSE STRUCTURE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Empathy & Validation (1–2 warm sentences that show you truly heard them)
2. Reflection (mirror the emotion: "It sounds like you're feeling...")
3. Practical Support (one concrete technique, reframe, or insight)
4. Engagement (ONE open-ended question or a gentle activity invitation)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MOOD-ADAPTIVE RESPONSES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Mild distress (1–3): Warmth + affirmation + light mood booster
• Moderate distress (4–6): Active coping strategies + grounding + reframing
• High distress (7–8): Intensive support + strong encouragement to seek professional help
• Severe / Crisis (9–10): IMMEDIATELY provide crisis resources + unconditional warm support

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MICRO-INTERVENTIONS (suggest contextually)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Breathing: Box breathing (4-4-4-4), 4-7-8, physiological sigh
• Grounding: 5-4-3-2-1 senses, cold water on wrists, feet on floor
• Movement: Quick walk, shake it out, progressive muscle relaxation
• Cognitive: Write the worry down, challenge the thought, perspective shift
• Social: Reach out to one trusted person, share something small
• Self-care: 8 minutes of sunlight, hydration, a nourishing meal

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CRITICAL SAFETY RULES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• NEVER diagnose any mental health condition
• NEVER recommend, adjust, or comment on medication
• ALWAYS recommend professional help for persistent or serious symptoms
• If you detect ANY hint of suicidal ideation, self-harm, or immediate danger:
  → Respond with deep compassion first
  → Immediately provide: "988 Suicide & Crisis Lifeline (call/text 988)" and "Crisis Text Line (text HOME to 741741)"
  → Strongly encourage immediate connection with a trusted person or professional
  → Do NOT leave the topic — stay present and supportive

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DISCLAIMER (mention occasionally, not every message)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"I'm here to support you, but I'm not a substitute for professional mental health care. If things feel overwhelming, please reach out to a licensed therapist or counselor."
""".strip()


MOOD_EXTRACTION_PROMPT = """
Analyze the user's message and the AI response, then extract mood data.
Return ONLY a valid JSON object with this exact structure:

{
  "mood": "<one of: happy, calm, hopeful, anxious, stressed, sad, angry, overwhelmed, hopeless, confused, neutral>",
  "intensity": <integer 1-10, where 1=very mild, 10=extreme>,
  "sentiment": "<positive | negative | neutral | mixed>",
  "triggers": ["<trigger1>", "<trigger2>"],
  "crisis_detected": <true | false>,
  "suggested_intervention": "<one of: box_breathing, grounding_54321, cognitive_reframe, progressive_relaxation, gratitude_practice, journaling, reach_out, physical_activity, self_compassion, crisis_support | null>"
}

Rules:
- triggers: identify specific stressors mentioned (work, relationships, finances, academic, health, loneliness, etc.)
- crisis_detected: true if ANY expression of suicidal thoughts, self-harm, hopelessness about living, or immediate danger
- intensity: base on emotional language strength, word choice, and context
- Be accurate — this data drives safety decisions
"""


# ── Azure OpenAI Client ───────────────────────────────────────────────────────

def _get_client() -> AzureOpenAI:
    if not settings.azure_openai_api_key:
        raise ValueError(
            "AZURE_OPENAI_API_KEY is not set. Add it to backend/.env"
        )
    if not settings.azure_openai_endpoint:
        raise ValueError(
            "AZURE_OPENAI_ENDPOINT is not set. Add it to backend/.env"
        )
    return AzureOpenAI(
        api_key=settings.azure_openai_api_key,
        azure_endpoint=settings.azure_openai_endpoint,
        api_version=settings.azure_openai_api_version,
    )


# ── Core Functions ─────────────────────────────────────────────────────────────

def build_history_messages(history: list[dict]) -> list[dict]:
    """Convert stored messages to OpenAI message format (last 20 messages for context)."""
    return [
        {"role": msg["role"], "content": msg["content"]}
        for msg in history[-20:]
    ]


def chat_completion(
    message: str,
    conversation_history: list[dict],
    session_id: Optional[str] = None,
) -> str:
    """
    Generate an empathetic, therapeutically-informed response.

    Args:
        message: The user's current message
        conversation_history: List of previous messages [{role, content}]
        session_id: Optional session identifier for logging

    Returns:
        AI-generated response string
    """
    client = _get_client()

    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages.extend(build_history_messages(conversation_history))
    messages.append({"role": "user", "content": message})

    response = client.chat.completions.create(
        model=settings.azure_openai_deployment,
        messages=messages,
        temperature=0.75,
        max_tokens=500,
        presence_penalty=0.3,
        frequency_penalty=0.2,
    )

    return response.choices[0].message.content.strip()


def extract_mood_data(user_message: str, ai_response: str) -> dict:
    """
    Extract structured mood/emotion data from the conversation turn.

    Returns a dict matching MoodData schema.
    Falls back gracefully on parse errors.
    """
    client = _get_client()

    prompt = f"""User said: "{user_message}"
AI responded: "{ai_response}"

{MOOD_EXTRACTION_PROMPT}"""

    try:
        response = client.chat.completions.create(
            model=settings.azure_openai_deployment,
            messages=[
                {"role": "system", "content": "You are a precise mood analysis engine. Return only valid JSON."},
                {"role": "user", "content": prompt},
            ],
            temperature=0.1,
            max_tokens=300,
            response_format={"type": "json_object"},
        )

        raw = response.choices[0].message.content.strip()
        data = json.loads(raw)

        # Sanitize and validate fields
        valid_moods = {
            "happy", "calm", "hopeful", "anxious", "stressed",
            "sad", "angry", "overwhelmed", "hopeless", "confused", "neutral"
        }
        data["mood"] = data.get("mood", "neutral").lower()
        if data["mood"] not in valid_moods:
            data["mood"] = "neutral"

        data["intensity"] = max(1, min(10, int(data.get("intensity", 5))))
        data["sentiment"] = data.get("sentiment", "neutral")
        data["triggers"] = data.get("triggers", [])
        data["crisis_detected"] = bool(data.get("crisis_detected", False))
        data["suggested_intervention"] = data.get("suggested_intervention")

        return data

    except Exception as e:
        logger.warning(f"Mood extraction failed: {e}")
        return {
            "mood": "neutral",
            "intensity": 5,
            "sentiment": "neutral",
            "triggers": [],
            "crisis_detected": False,
            "suggested_intervention": None,
        }


def analyze_patterns(messages: list[dict]) -> list[dict]:
    """
    Analyze conversation history to detect behavioral patterns and trends.

    Returns a list of pattern insights.
    """
    if len(messages) < 5:
        return []

    client = _get_client()

    # Build a summary of recent messages for pattern analysis
    summary_lines = []
    for msg in messages[-30:]:
        if msg["role"] == "user":
            summary_lines.append(f"User: {msg['content'][:100]}")

    conversation_summary = "\n".join(summary_lines)

    prompt = f"""Analyze this conversation history for mental health patterns.

{conversation_summary}

Return a JSON array of pattern insights (max 4), each with:
{{
  "type": "<recurring_stress | emotional_escalation | avoidance | progress | isolation | catastrophizing>",
  "description": "<brief, compassionate description>",
  "severity": "<info | warning | alert>",
  "recommendation": "<one specific, actionable recommendation>"
}}

Be compassionate and constructive. Focus on patterns that would genuinely help the user."""

    try:
        response = client.chat.completions.create(
            model=settings.azure_openai_deployment,
            messages=[
                {"role": "system", "content": "You are a mental health pattern analyst. Return only valid JSON array."},
                {"role": "user", "content": prompt},
            ],
            temperature=0.2,
            max_tokens=400,
            response_format={"type": "json_object"},
        )
        raw = response.choices[0].message.content.strip()
        parsed = json.loads(raw)

        # Handle both array and {"patterns": [...]} format
        if isinstance(parsed, list):
            return parsed
        return parsed.get("patterns", parsed.get("insights", []))

    except Exception as e:
        logger.warning(f"Pattern analysis failed: {e}")
        return []
