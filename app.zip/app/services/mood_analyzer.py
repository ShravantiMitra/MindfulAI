"""
Mood Analyzer — Lightweight sentiment and mood analysis.

Used as a fast pre-filter before calling the full AI extraction.
VADER provides fast rule-based sentiment; the AI service handles nuanced extraction.
"""

from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from typing import Optional

_analyzer = SentimentIntensityAnalyzer()

# Mood keyword mappings for rapid detection
MOOD_KEYWORDS = {
    "happy": ["happy", "great", "amazing", "wonderful", "joyful", "excited", "fantastic", "good", "love", "blessed", "grateful", "thrilled"],
    "calm": ["calm", "peaceful", "relaxed", "fine", "okay", "serene", "content", "tranquil", "balanced"],
    "hopeful": ["hopeful", "better", "improving", "optimistic", "looking forward", "things are getting", "progress"],
    "anxious": ["anxious", "anxiety", "nervous", "worried", "panic", "fear", "scared", "uneasy", "dread", "apprehensive", "on edge"],
    "stressed": ["stressed", "stress", "pressure", "overwhelmed", "too much", "swamped", "burned out", "burnout", "exhausted", "tension"],
    "sad": ["sad", "upset", "crying", "tears", "depressed", "unhappy", "heartbroken", "grief", "loss", "miss", "lonely", "alone"],
    "angry": ["angry", "anger", "furious", "frustrated", "mad", "rage", "irritated", "annoyed", "hate", "resentful"],
    "overwhelmed": ["overwhelmed", "can't cope", "too much", "breaking down", "falling apart", "drowning", "suffocating"],
    "hopeless": ["hopeless", "helpless", "pointless", "worthless", "useless", "nothing matters", "no hope", "giving up"],
    "confused": ["confused", "lost", "don't know", "uncertain", "unsure", "mixed up", "don't understand"],
}

NEGATIVE_MOODS = {"anxious", "stressed", "sad", "angry", "overwhelmed", "hopeless"}
POSITIVE_MOODS = {"happy", "calm", "hopeful"}


def quick_sentiment(text: str) -> dict:
    """
    Fast VADER sentiment analysis.

    Returns dict with compound, pos, neu, neg scores and a label.
    """
    scores = _analyzer.polarity_scores(text)
    compound = scores["compound"]

    if compound >= 0.05:
        label = "positive"
    elif compound <= -0.05:
        label = "negative"
    else:
        label = "neutral"

    return {
        "label": label,
        "compound": round(compound, 3),
        "positive": round(scores["pos"], 3),
        "negative": round(scores["neg"], 3),
        "neutral": round(scores["neu"], 3),
    }


def detect_mood_from_keywords(text: str) -> Optional[str]:
    """
    Rapid keyword-based mood detection.
    Returns the most prominent mood or None.
    """
    text_lower = text.lower()
    scores = {}

    for mood, keywords in MOOD_KEYWORDS.items():
        count = sum(1 for kw in keywords if kw in text_lower)
        if count > 0:
            scores[mood] = count

    if not scores:
        return None

    return max(scores, key=scores.get)


def estimate_intensity(text: str, sentiment: dict) -> int:
    """
    Estimate emotional intensity (1–10) from text features and sentiment score.
    """
    # Base from sentiment compound score
    compound = abs(sentiment["compound"])
    base = int(compound * 8) + 1  # 1–9 range

    # Boost for emphatic language
    emphatic_markers = [
        "really", "very", "so", "extremely", "incredibly", "absolutely",
        "completely", "totally", "utterly", "devastated", "terrified",
        "never", "always", "everything", "nothing", "everyone", "no one",
        "!!!", "can't take", "breaking", "falling apart",
    ]
    text_lower = text.lower()
    boosts = sum(1 for m in emphatic_markers if m in text_lower)
    intensity = min(10, base + min(boosts, 2))

    # Minimum intensity for very short stressed messages
    if len(text.strip()) < 20 and sentiment["label"] == "negative":
        intensity = max(intensity, 4)

    return max(1, intensity)


def get_mood_color(mood: str) -> str:
    """Return a UI color class for a given mood."""
    colors = {
        "happy": "#10B981",      # green
        "calm": "#3B82F6",       # blue
        "hopeful": "#8B5CF6",    # purple
        "anxious": "#F59E0B",    # amber
        "stressed": "#F97316",   # orange
        "sad": "#6366F1",        # indigo
        "angry": "#EF4444",      # red
        "overwhelmed": "#EC4899", # pink
        "hopeless": "#6B7280",   # gray
        "confused": "#14B8A6",   # teal
        "neutral": "#94A3B8",    # slate
    }
    return colors.get(mood, "#94A3B8")


def get_mood_emoji(mood: str) -> str:
    emojis = {
        "happy": "😊",
        "calm": "😌",
        "hopeful": "🌟",
        "anxious": "😰",
        "stressed": "😤",
        "sad": "😢",
        "angry": "😠",
        "overwhelmed": "😵",
        "hopeless": "😞",
        "confused": "😕",
        "neutral": "😐",
    }
    return emojis.get(mood, "😐")
