"""
MindfulAI — 24/7 Mental Health Support Assistant
FastAPI Backend Entry Point
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import get_settings
from app.database import create_tables
from app.routes import chat, mood, wellness, analytics

settings = get_settings()

app = FastAPI(
    title="MindfulAI API",
    description="24/7 Mental Health Support Assistant — Compassionate AI with evidence-based wellness tools",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

# CORS for React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize database on startup
@app.on_event("startup")
def startup():
    create_tables()


# Routes
app.include_router(chat.router,      prefix="/api/chat",      tags=["Chat"])
app.include_router(mood.router,      prefix="/api/mood",      tags=["Mood Tracking"])
app.include_router(wellness.router,  prefix="/api/wellness",  tags=["Wellness"])
app.include_router(analytics.router, prefix="/api/analytics", tags=["Analytics"])


@app.get("/", tags=["Health"])
def root():
    return {
        "status": "online",
        "app": "MindfulAI",
        "version": "1.0.0",
        "message": "Mental health support is available 24/7",
        "crisis_resources": {
            "US": "988 Suicide & Crisis Lifeline — call/text 988",
            "text": "Crisis Text Line — text HOME to 741741",
        },
    }


@app.get("/health", tags=["Health"])
def health_check():
    return {"status": "healthy"}
