"""
Analytics routes — Conversation patterns, mood summaries, and personalized recommendations.
"""

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session as DBSession

from app.database import get_db
from app.models.db_models import Session, Message, MoodEntry
from app.services import ai_service

router = APIRouter()


@router.get("/summary/{session_id}")
def get_summary(session_id: str, db: DBSession = Depends(get_db)):
    """High-level session summary."""
    session = db.query(Session).filter(Session.id == session_id).first()
    total_messages = (
        db.query(Message).filter(Message.session_id == session_id).count()
    )
    crisis_count = (
        db.query(Message)
        .filter(Message.session_id == session_id, Message.crisis_detected == True)
        .count()
    )

    return {
        "session_id": session_id,
        "total_messages": total_messages,
        "crisis_count": crisis_count,
        "created_at": session.created_at.isoformat() if session and session.created_at else None,
        "last_active": session.last_active.isoformat() if session and session.last_active else None,
    }


@router.get("/patterns/{session_id}")
def get_patterns(session_id: str, db: DBSession = Depends(get_db)):
    """
    AI-powered conversation pattern analysis.
    Identifies recurring stressors, emotional trends, and behavioral patterns.
    """
    messages = (
        db.query(Message)
        .filter(Message.session_id == session_id)
        .order_by(Message.created_at.asc())
        .all()
    )

    if len(messages) < 5:
        return {
            "patterns": [],
            "message": "Keep chatting to unlock pattern insights — they appear after a few conversations.",
        }

    history = [{"role": msg.role, "content": msg.content} for msg in messages]

    try:
        patterns = ai_service.analyze_patterns(history)
    except Exception:
        patterns = []

    return {"patterns": patterns, "analyzed_messages": len(messages)}


@router.get("/recommendations/{session_id}")
def get_recommendations(session_id: str, db: DBSession = Depends(get_db)):
    """
    Return personalized wellness recommendations based on mood history and patterns.
    """
    from collections import Counter
    import json
    from app.services.wellness_service import get_tips_by_mood, get_intervention_for_mood

    messages = (
        db.query(Message)
        .filter(
            Message.session_id == session_id,
            Message.role == "user",
            Message.mood.isnot(None),
        )
        .order_by(Message.created_at.desc())
        .limit(10)
        .all()
    )

    if not messages:
        dominant_mood = "neutral"
    else:
        moods = [msg.mood for msg in messages]
        dominant_mood = Counter(moods).most_common(1)[0][0]

    tips = get_tips_by_mood(dominant_mood, limit=3)
    intervention = get_intervention_for_mood(dominant_mood)

    return {
        "dominant_mood": dominant_mood,
        "recommended_tips": tips,
        "suggested_intervention": intervention,
        "personalized_message": _get_recommendation_message(dominant_mood),
    }


def _get_recommendation_message(mood: str) -> str:
    messages = {
        "anxious": "Based on your recent conversations, grounding and breathing exercises may help most right now.",
        "stressed": "Your sessions show signs of high stress. Short breathing breaks and movement can make a real difference.",
        "sad": "Gentle self-compassion practices and expressive writing tend to help when you're feeling down.",
        "angry": "Physical movement and progressive muscle relaxation can help release tension when frustration builds.",
        "overwhelmed": "When everything feels like too much, starting with one grounding technique can help you re-center.",
        "hopeless": "During difficult times, small acts of gratitude and self-compassion can slowly shift your perspective.",
        "happy": "You seem to be in a positive space — this is a great time to build on good habits.",
        "calm": "Your calm energy is a foundation — mindfulness practices can deepen this further.",
        "neutral": "Regular wellness practices help maintain emotional balance — explore what resonates with you.",
    }
    return messages.get(mood, "Explore our wellness library to find practices that resonate with you.")
