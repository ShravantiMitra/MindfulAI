"""
Wellness routes — Tips, interventions, and the micro-intervention library.
"""

from fastapi import APIRouter, HTTPException
from app.services import wellness_service

router = APIRouter()


@router.get("/categories")
def get_categories():
    """Return all wellness categories."""
    return wellness_service.get_all_categories()


@router.get("/tips")
def get_all_tips():
    """Return all wellness tips."""
    return {"tips": wellness_service.get_all_tips()}


@router.get("/tips/mood/{mood}")
def get_tips_for_mood(mood: str, limit: int = 3):
    """Return wellness tips most relevant to a given mood."""
    tips = wellness_service.get_tips_by_mood(mood, limit=limit)
    return {"mood": mood, "tips": tips}


@router.get("/tips/category/{category_id}")
def get_tips_by_category(category_id: str):
    """Return all tips for a specific category."""
    tips = wellness_service.get_tips_by_category(category_id)
    if not tips:
        raise HTTPException(status_code=404, detail=f"Category '{category_id}' not found")
    return {"category": category_id, "tips": tips}


@router.get("/intervention/{intervention_id}")
def get_intervention(intervention_id: str):
    """Return a specific guided intervention."""
    intervention = wellness_service.get_intervention(intervention_id)
    if not intervention:
        raise HTTPException(status_code=404, detail=f"Intervention '{intervention_id}' not found")
    return intervention


@router.get("/intervention/mood/{mood}")
def get_intervention_for_mood(mood: str):
    """Return the best micro-intervention for a given mood."""
    intervention = wellness_service.get_intervention_for_mood(mood)
    if not intervention:
        raise HTTPException(status_code=404, detail="No intervention found for mood")
    return intervention


@router.get("/daily-tip")
def get_daily_tip():
    """Return a random daily wellness tip."""
    tip = wellness_service.get_daily_tip()
    return {"tip": tip}
