"""
Mood routes — Manual mood logging and history retrieval.
"""

import json
from collections import Counter
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session as DBSession

from app.database import get_db
from app.models.schemas import MoodLogRequest, MoodEntryResponse, MoodInsights
from app.models.db_models import MoodEntry, Message

router = APIRouter()


@router.post("/log", response_model=MoodEntryResponse)
def log_mood(request: MoodLogRequest, db: DBSession = Depends(get_db)):
    """Manually log a mood entry."""
    entry = MoodEntry(
        session_id=request.session_id,
        mood=request.mood,
        intensity=request.intensity,
        triggers=json.dumps(request.triggers or []),
        notes=request.notes,
        source=request.source,
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)

    return MoodEntryResponse(
        id=entry.id,
        session_id=entry.session_id,
        mood=entry.mood,
        intensity=entry.intensity,
        triggers=json.loads(entry.triggers) if entry.triggers else [],
        notes=entry.notes,
        source=entry.source,
        created_at=entry.created_at,
    )


@router.get("/history/{session_id}")
def get_mood_history(session_id: str, limit: int = 30, db: DBSession = Depends(get_db)):
    """Return mood history combining auto-detected and manual entries."""
    # Auto-detected moods from chat messages
    chat_moods = (
        db.query(Message)
        .filter(
            Message.session_id == session_id,
            Message.role == "user",
            Message.mood.isnot(None),
        )
        .order_by(Message.created_at.asc())
        .limit(limit)
        .all()
    )

    # Manual mood logs
    manual_moods = (
        db.query(MoodEntry)
        .filter(MoodEntry.session_id == session_id)
        .order_by(MoodEntry.created_at.asc())
        .limit(limit)
        .all()
    )

    chat_entries = [
        {
            "id": f"chat_{msg.id}",
            "mood": msg.mood,
            "intensity": msg.mood_intensity or 5,
            "triggers": json.loads(msg.triggers) if msg.triggers else [],
            "source": "chat",
            "created_at": msg.created_at.isoformat() if msg.created_at else None,
        }
        for msg in chat_moods
        if msg.mood
    ]

    manual_entries = [
        {
            "id": f"manual_{entry.id}",
            "mood": entry.mood,
            "intensity": entry.intensity,
            "triggers": json.loads(entry.triggers) if entry.triggers else [],
            "notes": entry.notes,
            "source": "manual",
            "created_at": entry.created_at.isoformat() if entry.created_at else None,
        }
        for entry in manual_moods
    ]

    # Merge and sort by time
    all_entries = sorted(
        chat_entries + manual_entries,
        key=lambda x: x["created_at"] or "",
    )

    return {"entries": all_entries[-limit:], "total": len(all_entries)}


@router.get("/insights/{session_id}", response_model=MoodInsights)
def get_mood_insights(session_id: str, db: DBSession = Depends(get_db)):
    """Compute mood insights and trends for a session."""
    messages = (
        db.query(Message)
        .filter(
            Message.session_id == session_id,
            Message.role == "user",
            Message.mood.isnot(None),
        )
        .order_by(Message.created_at.asc())
        .all()
    )

    if not messages:
        return MoodInsights(
            average_intensity=5.0,
            dominant_mood="neutral",
            mood_distribution={},
            common_triggers=[],
            trend="stable",
            streak_days=0,
        )

    intensities = [msg.mood_intensity or 5 for msg in messages]
    moods = [msg.mood for msg in messages]
    all_triggers = []
    for msg in messages:
        if msg.triggers:
            try:
                all_triggers.extend(json.loads(msg.triggers))
            except Exception:
                pass

    mood_counts = Counter(moods)
    dominant_mood = mood_counts.most_common(1)[0][0]
    avg_intensity = sum(intensities) / len(intensities)
    trigger_counts = Counter(all_triggers)
    common_triggers = [t for t, _ in trigger_counts.most_common(5)]

    # Trend: compare first half vs second half average intensity
    trend = "stable"
    if len(intensities) >= 4:
        mid = len(intensities) // 2
        first_avg = sum(intensities[:mid]) / mid
        second_avg = sum(intensities[mid:]) / len(intensities[mid:])
        if second_avg < first_avg - 0.8:
            trend = "improving"
        elif second_avg > first_avg + 0.8:
            trend = "declining"

    return MoodInsights(
        average_intensity=round(avg_intensity, 1),
        dominant_mood=dominant_mood,
        mood_distribution=dict(mood_counts),
        common_triggers=common_triggers,
        trend=trend,
        streak_days=len(set(
            msg.created_at.date().isoformat()
            for msg in messages
            if msg.created_at
        )),
    )
