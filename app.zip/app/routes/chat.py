"""
Chat routes — Core conversation endpoint.
Handles message processing, crisis detection, mood extraction, and response generation.
"""

import json
import logging
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session as DBSession

from app.database import get_db
from app.models.schemas import ChatRequest, ChatResponse, MoodData
from app.models.db_models import Session, Message
from app.services import ai_service, crisis_detector, wellness_service
from app.services.crisis_detector import detect_crisis, should_prepend_resources

logger = logging.getLogger(__name__)
router = APIRouter()


def _get_or_create_session(session_id: str, nickname: str | None, db: DBSession) -> Session:
    session = db.query(Session).filter(Session.id == session_id).first()
    if not session:
        session = Session(id=session_id, nickname=nickname)
        db.add(session)
        db.commit()
        db.refresh(session)
    return session


def _get_conversation_history(session_id: str, db: DBSession, limit: int = 20) -> list[dict]:
    messages = (
        db.query(Message)
        .filter(Message.session_id == session_id)
        .order_by(Message.created_at.asc())
        .limit(limit)
        .all()
    )
    return [{"role": msg.role, "content": msg.content} for msg in messages]


@router.post("/message", response_model=ChatResponse)
def send_message(request: ChatRequest, db: DBSession = Depends(get_db)):
    """
    Process a user message and return an AI-generated mental health support response.

    Pipeline:
    1. Get/create session
    2. Crisis detection (fast, keyword-based)
    3. Build conversation history for context
    4. Generate AI response
    5. Extract mood data
    6. Store messages to DB
    7. Return enriched response
    """
    # 1. Session management
    session = _get_or_create_session(request.session_id, request.nickname, db)

    # 2. Fast crisis detection
    crisis_result = detect_crisis(request.message)

    # 3. Conversation history for context
    history = _get_conversation_history(request.session_id, db)

    # 4. Generate AI response
    try:
        ai_reply = ai_service.chat_completion(
            message=request.message,
            conversation_history=history,
            session_id=request.session_id,
        )
    except ValueError as e:
        raise HTTPException(status_code=503, detail=str(e))
    except Exception as e:
        logger.error(f"AI service error: {e}")
        ai_reply = (
            "I'm here with you. I'm experiencing a brief technical issue, but I want you to know "
            "your feelings are valid and important. If you're in crisis, please reach out to the "
            "988 Suicide & Crisis Lifeline (call or text 988) immediately. I'll be back shortly."
        )

    # 5. Prepend crisis resources if needed
    if crisis_result.is_crisis:
        final_reply = should_prepend_resources(ai_reply, crisis_result)
    else:
        final_reply = ai_reply

    # 6. Extract mood data from the exchange
    mood_raw = ai_service.extract_mood_data(request.message, ai_reply)

    # Merge crisis detection from both keyword and AI
    crisis_detected = crisis_result.is_crisis or mood_raw.get("crisis_detected", False)
    if crisis_detected:
        mood_raw["crisis_detected"] = True

    mood_data = MoodData(
        mood=mood_raw["mood"],
        intensity=mood_raw["intensity"],
        sentiment=mood_raw["sentiment"],
        triggers=mood_raw.get("triggers", []),
        crisis_detected=crisis_detected,
        suggested_intervention=mood_raw.get("suggested_intervention"),
    )

    # 7. Persist messages
    user_msg = Message(
        session_id=request.session_id,
        role="user",
        content=request.message,
        mood=mood_data.mood,
        mood_intensity=mood_data.intensity,
        sentiment=mood_data.sentiment,
        triggers=json.dumps(mood_data.triggers),
        crisis_detected=crisis_detected,
    )
    db.add(user_msg)

    assistant_msg = Message(
        session_id=request.session_id,
        role="assistant",
        content=final_reply,
        intervention_suggested=mood_data.suggested_intervention,
    )
    db.add(assistant_msg)

    # Update session stats
    session.total_messages += 2
    session.last_active = datetime.utcnow()
    if crisis_detected:
        session.crisis_count += 1

    db.commit()

    # 8. Fetch relevant wellness tips
    suggested_wellness = None
    if mood_data.suggested_intervention:
        intervention = wellness_service.get_intervention(mood_data.suggested_intervention)
        if intervention:
            suggested_wellness = [intervention]

    if not suggested_wellness:
        tips = wellness_service.get_tips_by_mood(mood_data.mood, limit=2)
        suggested_wellness = tips if tips else None

    # 9. Compose response
    crisis_resources = crisis_result.resources if crisis_detected else None

    return ChatResponse(
        session_id=request.session_id,
        reply=final_reply,
        mood_data=mood_data,
        crisis_resources=crisis_resources,
        suggested_wellness=suggested_wellness,
    )


@router.get("/history/{session_id}")
def get_history(session_id: str, limit: int = 50, db: DBSession = Depends(get_db)):
    """Return conversation history for a session."""
    messages = (
        db.query(Message)
        .filter(Message.session_id == session_id)
        .order_by(Message.created_at.asc())
        .limit(limit)
        .all()
    )
    return [
        {
            "id": msg.id,
            "role": msg.role,
            "content": msg.content,
            "mood": msg.mood,
            "mood_intensity": msg.mood_intensity,
            "crisis_detected": msg.crisis_detected,
            "created_at": msg.created_at.isoformat() if msg.created_at else None,
        }
        for msg in messages
    ]


@router.delete("/session/{session_id}")
def clear_session(session_id: str, db: DBSession = Depends(get_db)):
    """Clear all messages for a session (privacy feature)."""
    db.query(Message).filter(Message.session_id == session_id).delete()
    db.commit()
    return {"message": "Session cleared", "session_id": session_id}
